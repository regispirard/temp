* Sébastien BEAU <sebastien.beau@akretion.com>
* Raphaël Reverdy <raphael.reverdy@akretion.com>
* Florian da Costa <florian.dacosta@akretion.com>
* Cédric Pigeon <cedric.pigeon@acsone.eu>
* Renato Lima <renato.lima@akretion.com>
* Benoît Guillot <benoit.guillot@akretion.com>
* Laurent Mignon <laurent.mignon@acsone.eu>
* Denis Roussel <denis.roussel@acsone.eu>
