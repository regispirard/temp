Usually, you will not install this module directly.
It will be a dependency of another module like
'shopinvader_algolia'.
