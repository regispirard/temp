Go to Connector menu.

Under the 'Search Engine Connector' menu,
you will find a list of all search engines (Backends) defined
