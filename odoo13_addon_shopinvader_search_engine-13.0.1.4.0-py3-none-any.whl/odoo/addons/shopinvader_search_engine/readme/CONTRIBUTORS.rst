* Sebastien BEAU <sebastien.beau@akretion.com>
* Laurent Mignon <laurent.mignon@acsone.eu>
* Benoît GUILLOT <benoit.guillot@akretion.com>
* Raphaël Reverdy <raphael.reverdy@akretion.com>
* Denis Roussel <denis.roussel@acsone.eu>
