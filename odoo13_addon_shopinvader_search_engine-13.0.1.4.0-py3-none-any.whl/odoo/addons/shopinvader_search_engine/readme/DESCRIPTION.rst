This module is a technical module to implement batch export of data to external indexation services.
The first concrete implementation allows to export data to Algolia.
