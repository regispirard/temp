12.0.1.0.0 (2018-11-06)
~~~~~~~~~~~~~~~~~~~~~~~

* [NEW] Initial V12 version. Complete rewrite from v11.
