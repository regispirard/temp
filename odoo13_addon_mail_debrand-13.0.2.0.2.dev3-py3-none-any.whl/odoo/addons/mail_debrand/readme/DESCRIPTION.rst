This module modifies the functionality of emails to remove the Odoo branding,
specifically the 'using Odoo' of notifications or the 'Powered by Odoo'
