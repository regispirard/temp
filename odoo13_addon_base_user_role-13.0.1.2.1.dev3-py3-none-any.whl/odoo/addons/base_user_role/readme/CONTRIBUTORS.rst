* Sébastien Alix <sebastien.alix@camptocamp.com>
* Duc, Dao Dong <duc.dd@komit-consulting.com> (https://komit-consulting.com)
* Jean-Charles Drubay <jc@komit-consulting.com> (https://komit-consulting.com)
* Harald Panten <harald.panten@sygel.es>

Do not contact contributors directly about support or help with technical issues.
