Images
------

* Oxygen Team: `Icon <http://www.iconarchive.com/show/oxygen-icons-by-oxygen-icons.org/Actions-user-group-new-icon.html>`_ (LGPL)
