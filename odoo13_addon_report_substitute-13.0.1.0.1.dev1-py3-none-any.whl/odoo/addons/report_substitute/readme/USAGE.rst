To use this module, you need to:

#. Go to 'Actions' / 'Reports'

#. Select the desired report you want to 'Substitution Rules'

#. In the substitutions page add a new line

#. Select the substitution report action

#. Set a domain to specify when this substitution should happen


When a user calls a report action, the system tries to find the first
substitution in with a domain that matches all records.
