This module adds a fax field into the partner form.
