* Francesco Apruzzese
* Aitor Bouzas <aitor.bouzas@adaptivecity.com>
* Pimolnat Suntian <pimolnats@ecosoft.co.th>
