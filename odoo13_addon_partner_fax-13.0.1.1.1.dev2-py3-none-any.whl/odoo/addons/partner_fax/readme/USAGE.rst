To use this module, you need to:

1. Go to the partner form
2. There you will see a new field called "Fax" that you can use to save the partner's Fax number
