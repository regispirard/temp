To configure this module, you need to:

#. Go to Connector > LocomotiveCMS > Backend
