10.0.1.0.0 (2018-06-11)
~~~~~~~~~~~~~~~~~~~~~~~

* [IMP] shopinvader_locomotive: Move connector_locomotive to shopinvader_locomotive;

12.0.1.0.0 (2019-06-05)
~~~~~~~~~~~~~~~~~~~~~~~

* [12.0][MIG] shopinvader_locomotive
