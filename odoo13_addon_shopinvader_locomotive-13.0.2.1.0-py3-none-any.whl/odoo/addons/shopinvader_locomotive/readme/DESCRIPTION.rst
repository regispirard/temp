Connector with LocomotiveCMS

Base module no feature is implemented
