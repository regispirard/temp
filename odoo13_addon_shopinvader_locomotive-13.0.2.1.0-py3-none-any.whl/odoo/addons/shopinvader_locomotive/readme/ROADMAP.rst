* Lib extraction
