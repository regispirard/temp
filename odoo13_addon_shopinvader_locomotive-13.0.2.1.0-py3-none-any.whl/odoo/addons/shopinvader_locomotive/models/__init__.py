from . import res_partner
from . import shopinvader_backend
from . import locomotive_binding
from . import shopinvader_partner
