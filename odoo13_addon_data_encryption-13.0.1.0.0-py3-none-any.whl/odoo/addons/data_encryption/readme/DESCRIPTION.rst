This module allows to encrypt and decrypt data. This module is not usable
by itself, it is a low level module which should work as a base for others.
An example is the module server_environment_data_encryption
