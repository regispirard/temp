To configure this module, you need to:

#. Enable the "Printing / Print User" option under access
   rights to give users the ability to view the print menu.
