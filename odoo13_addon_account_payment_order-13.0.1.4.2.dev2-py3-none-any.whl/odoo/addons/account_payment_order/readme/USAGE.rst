You can create a Payment order via the menu Invoicing/Accounting > Payments > Payment Orders and then select the move lines to pay.

You can create a Debit order via the menu Invoicing/Accounting > Payments > Debit Orders and then select the move lines to debit.

This module also adds a button *Add to Payment Order* on supplier invoices and a button *Add to Debit Order* on customer invoices.

You can print a Payment order via the menu Invoicing/Accounting > Payments > Payment Orders and then select the payment oder to print.
