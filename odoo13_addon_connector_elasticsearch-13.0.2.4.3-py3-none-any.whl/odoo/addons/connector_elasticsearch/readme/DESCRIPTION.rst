This addon provides the bases to implement addons to export information to
Elasticsearch_ indexes.

.. _Elasticsearch: https://www.elastic.co/
