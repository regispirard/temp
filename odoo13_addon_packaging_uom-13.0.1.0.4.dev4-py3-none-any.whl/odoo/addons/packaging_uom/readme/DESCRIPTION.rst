This module was written to use unit of measure instead of quantity by package
in the definition of packaging.
The goal is to ease the use of packaging in sale and purchase.
