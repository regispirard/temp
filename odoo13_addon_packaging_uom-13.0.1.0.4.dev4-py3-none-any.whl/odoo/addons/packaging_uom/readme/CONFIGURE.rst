To configure this module, you need to:

* on product packaging define the unit of measure to use.
