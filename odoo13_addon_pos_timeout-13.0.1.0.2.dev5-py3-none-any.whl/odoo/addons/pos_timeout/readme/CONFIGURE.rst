To configure this module, you need to:

* Go to 'Point Of Sale' / 'Configuration' / 'Point of Sale' and edit your
  PoS Config, setting a timeout

.. figure:: ../static/description/pos_config.png
   :alt: PoS Configuration
   :width: 800 px

If not set, the default Odoo timeout will be used. (7.5 seconds in V10.0)
