* André Paramés Pereira <github@andreparames.com>
* Hughes Damry <hughes.damry@acsone.eu>

Do not contact contributors directly about support or help with technical issues.
