Creates a separate log for auditing the user actions. Can be configured to
log to any handler accepted by Python's logging (file, logstash, etc) in any
format.
