REST Services for ATOS Worldline SIPS Payments (base module without controller).
