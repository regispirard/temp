This module adds a "Split" button on the outgoing pickings form.

It works like the classical picking Transfer but it leaves both pickings
(picking and its backorder) as confirmed without processing the transfer.
