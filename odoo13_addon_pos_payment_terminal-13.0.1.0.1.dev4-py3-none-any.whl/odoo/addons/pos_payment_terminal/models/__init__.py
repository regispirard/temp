from . import pos_payment_method
