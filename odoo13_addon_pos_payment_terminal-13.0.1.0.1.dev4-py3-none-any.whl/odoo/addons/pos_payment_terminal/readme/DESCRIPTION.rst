This module adds support for credit card reader and checks printer
in the Point of Sale.
