* Aurelien Dumaine
* Alexis de Lattre <alexis.delattre@akretion.com>
* Sylvain LE GAL (https://twitter.com/legalsylvain)
