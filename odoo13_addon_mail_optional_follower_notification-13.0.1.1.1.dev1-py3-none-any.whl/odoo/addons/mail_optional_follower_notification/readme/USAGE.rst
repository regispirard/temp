To use this module, you need to use the checkbox near "Followers of the
document and" on mail.compose.message:

This field it's initialized to true to keep the standard behavior.

.. figure:: static/description/optional_follower_001.png
   :alt: Default checkbox

.. figure:: static/description/optional_follower_002.png
   :alt: Checkbox to avoid to notify automatically followers
