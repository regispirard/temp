This module adds the possibility to choose if you want to automatically
notify followers on mail.compose.message. By default, Odoo notify
automatically all followers.
