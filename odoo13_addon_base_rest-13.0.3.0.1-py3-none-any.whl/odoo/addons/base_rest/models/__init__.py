from . import rest_service_registration
