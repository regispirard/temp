In the point of sale, many installations work with cash registers with
anonymous customers. In that case, loading thousands, or even tens of
thousands of customers to each cash register is completely useless, and also
a huge danger for leaking privacy sensible data.

This module will limit the download of customer data to only those customers
where this has been specifically requested.
