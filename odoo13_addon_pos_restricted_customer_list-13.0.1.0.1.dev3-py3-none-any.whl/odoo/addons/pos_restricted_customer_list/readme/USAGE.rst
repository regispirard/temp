To allow a customer to be displayed in the PoS, just check the 'Available in POS' field.
