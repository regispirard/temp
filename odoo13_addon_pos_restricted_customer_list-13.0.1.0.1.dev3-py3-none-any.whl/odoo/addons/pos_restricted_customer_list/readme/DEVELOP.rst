The module will add a flag 'available_in_pos' to res.partner. It will override
to domain of customers downloaded with pos to only download the partners
where this flag has been set.
