* Sebastien Beau <sebastien.beau@akretion.com>
* Raphaël Reverdy <raphael.reverdy@akretion.com>
* Pedro M. Baeza <pedro.baeza@serviciosbaeza.com>
* Antiun Ingeniería S.L. - Jairo Llopis
* Denis Roussel <denis.roussel@acsone.eu>
* Quentin Groulard <quentin.groulard@acsone.eu>
