External image management depending on Storage File module.

It include these features:

* image resizing: thumbnail, etc.
* store metadata like: checksum, mimetype

Use cases:

- product images on CDN for e-commerce website
- raw products images on cheap storage (ie AWS Glacier, AWS S3)
