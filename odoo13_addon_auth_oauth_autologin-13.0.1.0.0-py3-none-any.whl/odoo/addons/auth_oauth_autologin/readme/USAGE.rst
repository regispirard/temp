When configured, the Odoo login page redirects to the OAuth identify provider
for authentication and login in Odoo. To access the regular Odoo login page,
visit ``/web/login?no_autologin``.
