.. image:: https://img.shields.io/badge/licence-AGPL--3-blue.svg
   :target: http://www.gnu.org/licenses/agpl-3.0-standalone.html
   :alt: License: AGPL-3

=======================
Base Sparse Field List
=======================

This module allow to store list in Serialized.
This is a technical module

Credits
=======

Contributors
------------

* BEAU Sébastien <sebastien.beau@akretion.com>
* BEAL David <david.beal@akretion.com>

Maintainer
----------
Akretion
