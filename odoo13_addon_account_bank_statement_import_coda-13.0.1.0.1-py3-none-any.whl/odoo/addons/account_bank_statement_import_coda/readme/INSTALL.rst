To install this module, you need to install the python library `pycoda <https://pypi.python.org/pypi/pycoda>`__.
