==========================================================
Access to technical features without activating debug mode
==========================================================

In Odoo 9.0 and later, the debug mode grants every employee user access to the
technical features. This module enables persistent access to technical features
based on user preference.
