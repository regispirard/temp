REST Services for manual payments like bank transfer, check (base module without controller).
