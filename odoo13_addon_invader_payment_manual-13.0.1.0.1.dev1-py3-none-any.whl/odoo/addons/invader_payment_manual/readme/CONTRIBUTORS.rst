* Sébastien BEAU <sebastien.beau@akretion.com>
* Laurent Mignon <laurent.mignon@acsone.com>
* Simone Orsi <simone.orsi@camptocamp.com>
* Denis Roussel <denis.roussel@acsone.eu>
