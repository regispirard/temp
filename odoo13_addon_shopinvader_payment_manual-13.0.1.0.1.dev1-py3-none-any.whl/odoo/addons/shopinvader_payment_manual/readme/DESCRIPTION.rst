REST Services for Manual Payments (/shopinvader route).
