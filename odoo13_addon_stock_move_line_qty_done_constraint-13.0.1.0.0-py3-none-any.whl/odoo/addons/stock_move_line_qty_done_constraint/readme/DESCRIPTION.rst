This module allows to restrict filled in quantities on stock picking move
lines. It allows only lower or equal quantities than in 'Reserved' quantities.

Moreover, this behaviour can be activated on some particular Picking Types.
