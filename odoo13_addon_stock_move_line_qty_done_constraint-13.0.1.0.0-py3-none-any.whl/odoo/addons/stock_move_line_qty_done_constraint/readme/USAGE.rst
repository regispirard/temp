* Go to Inventory > Configuration > Warehouse > Operation Types
* Choose the one you need to restrict quantities.
* Check the box 'Restrict Quantity on Done Quantity'
* When a user will try to transfer more quantity than reserved one, it will
  raise an error.
