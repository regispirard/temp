Base module for implementing e-commerce payment methods.
This module mostly provides an abstract component (InvaderPaymentService)
and an abstract model (InvaderPayable).
