You just have to use your email template like usual. New attachments will be generated automatically with the email content.
