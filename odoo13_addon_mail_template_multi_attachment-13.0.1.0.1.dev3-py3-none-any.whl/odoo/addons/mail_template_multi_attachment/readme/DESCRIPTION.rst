This module add possibility to generate more than one attachment into your email template.
