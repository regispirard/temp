Just go on an email template and set attachments into "Attachments" tab.

You can fill the "Simple attachment" if you need only 1 document (like Odoo standard).
You can also fill "Multi attachments" section if you need to add more document generation.

You can fill only "Multi attachments" section and let empty "Simple attachment" if you want.
