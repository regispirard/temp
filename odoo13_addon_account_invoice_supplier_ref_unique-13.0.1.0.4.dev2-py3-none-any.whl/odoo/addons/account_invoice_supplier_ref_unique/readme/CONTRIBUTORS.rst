* Marc Cassuto <marc.cassuto@savoirfairelinux.com>
* Mathieu Benoit <mathieu.benoit@savoirfairelinux.com>
* Alexis de Lattre <alexis.delattre@akretion.com>
* Thomas Binsfeld <thomas.binsfeld@acsone.eu>
* Andrea Stirpe <a.stirpe@onestein.nl>
