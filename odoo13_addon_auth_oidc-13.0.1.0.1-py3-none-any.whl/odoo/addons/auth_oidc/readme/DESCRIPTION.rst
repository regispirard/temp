This module allows users to login through an OpenID Connect provider using the
authorization code flow or implicit flow.

Note the implicit flow is not recommended because it exposes access tokens to
the browser and in http logs.
