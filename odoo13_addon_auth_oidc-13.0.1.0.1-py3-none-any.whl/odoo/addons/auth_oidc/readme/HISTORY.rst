13.0.1.0.0 2020-04-10
~~~~~~~~~~~~~~~~~~~~~

* Odoo 13 migration, add authorization code flow.

10.0.1.0.0 2018-10-05
~~~~~~~~~~~~~~~~~~~~~

* Initial implementation
