This module allows to set justification on inventories
