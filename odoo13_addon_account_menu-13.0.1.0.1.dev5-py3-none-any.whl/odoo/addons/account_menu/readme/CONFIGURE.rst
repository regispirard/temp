To see all the menus, make sure:

* Your user is member of the group
  "Technical Settings / Show Full Accounting Features"

* The page is running in debug mode
