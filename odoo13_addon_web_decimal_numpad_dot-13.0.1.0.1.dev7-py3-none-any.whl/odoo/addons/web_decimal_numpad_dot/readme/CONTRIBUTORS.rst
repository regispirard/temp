* Oihane Crucelaegui <oihanecrucelaegi@avanzosc.es>
* Ana Juaristi <anajuaristi@avanzosc.es>
* Omar Castiñeira Saavedra <omar@comunitea.com>
* Oliver Dony <@odony>
* Wim Audenaert <Wim.Audenaert@ucamco.com>
* `Tecnativa <https://www.tecnativa.com>`_:

  * Pedro M. Baeza
  * David Vidal
  * Jairo Llopis
  * Ernesto Tejeda

* `C2i Change 2 improve <http://www.c2i.es>`_:

  * Eduardo Magdalena <emagdalena@c2i.es>
