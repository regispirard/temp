* Alexis de Lattre <alexis.delattre@akretion.com>
* Raphaël Valyi
* Stefan Rijnhart (Therp)
* Alexandre Fayolle
* Stéphane Bidoul <stephane.bidoul@acsone.eu>
* Danimar Ribeiro
* Angel Moya <angel.moya@domatix.com>
* `Tecnativa <https://www.tecnativa.com>`_:

  * Pedro M. Baeza <pedro.baeza@tecnativa.com>
  * Carlos Dauden <carlos.dauden@tecnativa.com>
* `DynApps <https://www.dynapps.be>`_:

  * Raf Ven <raf.ven@dynapps.be>
