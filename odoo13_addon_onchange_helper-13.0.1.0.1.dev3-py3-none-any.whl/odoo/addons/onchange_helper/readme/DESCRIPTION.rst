This is a technical module. Its goal is to ease the play of onchange method directly called from Python code.
