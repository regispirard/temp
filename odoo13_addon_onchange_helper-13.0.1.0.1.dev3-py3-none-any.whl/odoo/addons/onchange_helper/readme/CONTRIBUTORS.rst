* Guewen Baconnier <guewen.baconnier@camptocamp.com>
* Florian da Costa <florian.dacosta@akretion.com>
* Andrea Stirpe <a.stirpe@onestein.nl>
* Souheil Bejaoui <souheil.bejaoui@acsone.eu>
