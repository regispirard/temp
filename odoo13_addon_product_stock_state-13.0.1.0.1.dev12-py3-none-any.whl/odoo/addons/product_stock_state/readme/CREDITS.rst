The development of this module has been financially supported by:

* Akretion R&D
* Adaptoo
* GRAP, Groupement Régional Alimentaire de Proximité <http://www.grap.coop>
