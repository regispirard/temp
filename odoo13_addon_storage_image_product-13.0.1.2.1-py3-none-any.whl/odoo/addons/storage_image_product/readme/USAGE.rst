A) Categories

   Go to Sales > Configuration > Products > Product Categories.
   A new field Image is available to upload or use an existing image.

B) Products

   Go to Sales > Products. In variants tab, after the attributes selection, you will find the images.


For uploading and managing the images see the module storage_image.
