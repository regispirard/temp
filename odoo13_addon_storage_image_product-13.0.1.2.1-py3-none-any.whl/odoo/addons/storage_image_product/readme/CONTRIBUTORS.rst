* Raphaël Reverdy <raphael.reverdy@akretion.com>
* Denis Roussel <denis.roussel@acsone.eu>
* Quentin Groulard <quentin.groulard@acsone.eu>
