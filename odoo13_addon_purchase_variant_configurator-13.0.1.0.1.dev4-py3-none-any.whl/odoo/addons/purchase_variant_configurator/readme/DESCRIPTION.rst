This module allows you to create the product variant when a purchase order is
confirmed. It adds to the purchase line a product configurator, so that
selecting a product and its attributes can be created a new product variant.
