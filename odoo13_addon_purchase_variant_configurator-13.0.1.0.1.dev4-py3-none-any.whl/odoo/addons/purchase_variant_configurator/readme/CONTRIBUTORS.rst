* Oihane Crucelaegui <oihanecrucelaegi@avanzosc.es>
* David Díaz <d.diazp@gmail.com>
* Ana Juaristi <ajuaristio@gmail.com>
* `Tecnativa <https://www.tecnativa.com>`_:

  * Pedro M. Baeza
  * David Vidal
  * Ernesto Tejeda
