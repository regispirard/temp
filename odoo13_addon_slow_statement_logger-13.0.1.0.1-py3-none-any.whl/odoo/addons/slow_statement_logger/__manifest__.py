{
    "name": "Slow SQL Statement Logger",
    "summary": "Log slow SQL statements",
    "version": "13.0.1.0.1",
    "author": "ACSONE SA/NV, Odoo Community Association (OCA)",
    "license": "AGPL-3",
    "website": "https://github.com/OCA/server-tools/",
    "category": "Tools",
}
