Since roles on role history line have 'cascade' ondelete, role deletion leads
to role history line deletion. In order to keep history even in the case of
a role deletion, module could be upgraded.
