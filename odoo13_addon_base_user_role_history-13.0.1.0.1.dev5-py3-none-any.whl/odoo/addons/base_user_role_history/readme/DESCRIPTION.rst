This addon provides history for roles modifications on users.
Each time a role is added/updated/unlinked on a user, a new role history line
is created mentioning what changes were made and who made them.
Theses informations are directly accessible from users via a smart button.
