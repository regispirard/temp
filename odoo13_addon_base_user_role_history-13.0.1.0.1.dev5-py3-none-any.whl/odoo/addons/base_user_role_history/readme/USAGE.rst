Changes on user roles are easily accessible via a button on user form view.
