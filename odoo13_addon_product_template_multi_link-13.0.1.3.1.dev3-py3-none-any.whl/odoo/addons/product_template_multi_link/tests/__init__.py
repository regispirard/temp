from . import test_product_template_link_type
from . import test_product_template_link
