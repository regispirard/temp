To configure this module, you need to:

* on product packaging define the unit of measure to use.
* on supplier info define the packaging and minimum unit of measure quantity
    to use.
* use product packaging in purchase order to use the link unit of measure
