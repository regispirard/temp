- Use packaging in supplierinfo
- Use uom set in the packaging instead of purchase uom for purchase
- Add minimum quantity measure unit in supplierinfo
- On purchase order line compute the quantity with the quantity and unit of
    measure
