As soon as both **Account Payment Mode** and **Sale Automatic Workflow**
are installed, this module is installed.
