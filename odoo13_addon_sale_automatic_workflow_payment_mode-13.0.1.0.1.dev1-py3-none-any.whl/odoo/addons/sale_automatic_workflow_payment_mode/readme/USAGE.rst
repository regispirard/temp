When a payment mode is selected on a sales order, if it has an
automatic workflow, the sales order will use it.
