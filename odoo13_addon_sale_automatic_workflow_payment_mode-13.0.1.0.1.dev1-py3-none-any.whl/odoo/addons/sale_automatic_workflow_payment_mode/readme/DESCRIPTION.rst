This module is a glue for **Account Payment Sale** (of the OCA/bank-payment
project) and **Sale Automatic Workflow**.

When a payment mode is associated with an automatic workflow, this one
is automatically selected for the sales orders using this method.
