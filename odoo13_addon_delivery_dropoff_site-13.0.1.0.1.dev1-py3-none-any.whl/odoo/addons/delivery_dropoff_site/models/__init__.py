from . import dropoff_site
from . import res_partner
from . import sale_order
from . import procurement_group
from . import stock_picking
from . import stock_move
from . import delivery_carrier
