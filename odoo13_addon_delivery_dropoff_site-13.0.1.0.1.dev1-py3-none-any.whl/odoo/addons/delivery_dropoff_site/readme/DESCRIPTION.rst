This module extend Odoo functionnalities, regarding delivery features to
add a new concept of drop-off Sites.

Main international carriers provide transportation services to specific areas
managed by them or by subcontractors.

Then, recipients come pick up their packages in these sites.
