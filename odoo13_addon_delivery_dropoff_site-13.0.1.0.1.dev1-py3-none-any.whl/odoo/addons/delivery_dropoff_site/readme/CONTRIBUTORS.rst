* David BEAL <david.beal@akretion.com>
* Aymeric LECOMTE, akretion
* Sébastien BEAU <sebastien.beau@akretion.com>
* Sylvain LE GAL (https://twitter.com/legalsylvain)
