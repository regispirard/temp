* To configure drop-off sites, users should be member of 'Sale / Manager' or
  'Inventory / Manager'.

* To use this drop-off sites on sale orders, users should be member of
  'Technical Settings / Addresses in Sales Orders'.
