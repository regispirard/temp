* Holger Brunn <hbrunn@therp.nl>
* Nicolas JEUDY - Sudokeys (https://github.com/njeudy)
* Stephane (SOLIBRE) <stephane@omerp.net>
* Sylvain LE GAL (https://twitter.com/legalsylvain)
* Jérôme Thériault <jtheriault@metalsartigan.com>
* Lois Rilo <lois.rilo@forgeflow.com>
