To be compliant with python 3.x, the connector use the next version of the
python cmislib library not yet released at this stage. The lib can be
installed with:

::

  pip install git+https://github.com/apache/chemistry-cmislib.git@py3_compat#egg=cmislib
