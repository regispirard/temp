This module is the base for Odoo modules implementing different integration
scenario with a CMIS server.
It allows you to configure a CMIS backend in Odoo.
