* Laurent Mignon <laurent.mignon@acsone.eu>
* Maxime Chambreuil <maxime.chambreuil@savoirfairelinux.com>
* El Hadji Dem <elhadji.dem@savoirfairelinux.com>
