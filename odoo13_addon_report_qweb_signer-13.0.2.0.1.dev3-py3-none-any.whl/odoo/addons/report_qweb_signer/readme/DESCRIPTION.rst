This module extends the functionality of report module to sign
PDFs using a PKCS#12 certificate.
