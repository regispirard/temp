* Allow setting default dialog size per user.
