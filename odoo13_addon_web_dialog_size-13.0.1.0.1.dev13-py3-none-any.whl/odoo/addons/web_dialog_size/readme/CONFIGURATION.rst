By default, the module respects the caller's ``dialog_size`` option.
If you want to override this and have all dialogs maximized by default,
set the configuration parameter ``web_dialog_size.default_maximize`` to ``1``.
