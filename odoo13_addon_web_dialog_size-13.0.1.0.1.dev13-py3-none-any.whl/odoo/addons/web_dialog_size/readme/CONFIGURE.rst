If you want to set dialog boxes maximized by default, you need to:

#. Go to *Settings -> Technical -> Parameters -> System Parameters*
#. Add a new record with the text *web_dialog_size.default_maximize* in
    the *Key* field and the text *True* in the *Value* field
