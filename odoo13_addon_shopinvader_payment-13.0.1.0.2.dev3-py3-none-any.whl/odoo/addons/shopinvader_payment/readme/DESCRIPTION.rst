Add the payment information on the cart
