* Sebastien BEAU <sebastien.beau@akretion.com>
* Denis Roussel <denis.roussel@acsone.eu>
* Laurent Mignon <laurent.mignon@acsone.eu>
