# Copyright 2018 ACSONE SA/NV (<http://acsone.eu>)
# License LGPL-3.0 or later (http://www.gnu.org/licenses/lgpl.html).

from .compat import odoo  # noqa
from .compat import odoo_bin  # noqa
from .env import OdooEnvironment  # noqa
from .env_options import env_options  # noqa
