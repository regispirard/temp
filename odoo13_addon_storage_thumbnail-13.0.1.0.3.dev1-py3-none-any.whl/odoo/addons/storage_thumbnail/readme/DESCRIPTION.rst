External image thumbnail management depending on Storage File module.
