If you deactivate a company bank account, linked journals will still be active.
