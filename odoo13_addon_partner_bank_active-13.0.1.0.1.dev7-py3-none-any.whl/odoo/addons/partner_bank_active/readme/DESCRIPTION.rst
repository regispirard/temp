This module allows to deactivate a partner bank account.
