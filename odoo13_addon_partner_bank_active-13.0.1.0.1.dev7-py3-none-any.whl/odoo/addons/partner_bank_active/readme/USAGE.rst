To use this module, you need to:

#. Open the form view of a partner.
#. Go to tab Invoicing and click "View accounts detail".
#. Open the form view of one of the bank accounts in the list view.
#. Activate / deactivate the bank account by clicking Actions -> Archive / Unarchive

To access to a list/form view of all bank accounts in Odoo, you need to install
the Contacts module (Contacts/Configuration/Bank Accounts).
