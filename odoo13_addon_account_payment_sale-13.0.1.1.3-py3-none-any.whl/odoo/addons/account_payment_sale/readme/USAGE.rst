You are able to add a payment mode directly on a partner.
This payment mode is automatically associated to the sale order, then on related invoice.
This default value can be changed in a draft sale order or draft invoice.
