* Pedro M. Baeza
* Alexis de Lattre <alexis.delattre@akretion.com>
* Alexandre Fayolle
* Danimar Ribeiro
* Raphaël Valyi
* Raf Ven <raf.ven@dynapps.be>
