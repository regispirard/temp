* Antonio Espinosa <antonio.espinosa@tecnativa.com>
* Ferdinand Gassauer <office@chrcar.at>
* Gerhard Könighofer <gerhard.koenighofer@swing-system.com>
* Laurent Mignon <laurent.mignon@acsone.eu>
* Jairo Llopis <jairo.llopis@tecnativa.com>
* Dave Lasley <dave@laslabs.com>
* Simone Orsi <simone.orsi@camptocamp.com>
* Dennis Sluijk <d.sluijk@onestein.nl>
