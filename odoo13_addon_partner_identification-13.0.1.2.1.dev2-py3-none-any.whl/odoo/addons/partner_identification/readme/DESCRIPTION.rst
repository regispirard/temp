This module allows to manage all sort of identification numbers
and certificates which are assigned to a partner (company or individual)
and vary from country to country.

* Commercial register
* VAT ID
* Fiscal ID's
* Membership numbers
* Driver license
* etc
