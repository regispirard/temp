* If you want to search a partner by ID you will use advance search form.
  You can't search by issuer, valid dates, category or notes.
