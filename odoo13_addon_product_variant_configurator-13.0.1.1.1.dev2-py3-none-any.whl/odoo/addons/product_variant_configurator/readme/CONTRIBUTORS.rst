* Oihane Crucelaegui <oihanecrucelaegi@avanzosc.es>
* Pedro M. Baeza <pedro.baeza@tecnativa.com>
* Ana Juaristi <ajuaristio@gmail.com>
* Thomas Binsfeld <thomas.binsfeld@acsone.eu>
* Zakaria Makrelouf (acsone) <z.makrelouf@gmail.com>
* Stéphane Bidoul <stephane.bidoul@acsone.eu>
* Laurent Mignon <laurent.mignon@acsone.eu>
* David Vidal <david.vidal@tecnativa.com>
* Simone Versienti <s.versienti@apuliasoftware.it>
* Adria Gil Sorribes <adria.gil@forgeflow.com>
* Héctor Villarreal Ortega <hector.villarreal@forgeflow.com>
