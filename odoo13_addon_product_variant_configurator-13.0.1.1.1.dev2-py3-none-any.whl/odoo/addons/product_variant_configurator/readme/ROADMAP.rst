* Product Variant Configurator is not compatible with `website_sale`,
  current compute behavior for website_url collides with Product Variant Creation,
  glue module required.
