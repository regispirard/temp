13.0.1.0.0 (2019-09-30)
~~~~~~~~~~~~~~~~~~~~~~~

* [RELEASE] Port from V12.
* Selection lists do not support integers any longer
* Binary field now returns False when empty instead of none,
  change tests to reflect this
* work around an appels vs oranges warning
