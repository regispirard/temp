.. _roadmap:

#######
Roadmap
#######

Here is a list of things we may agree to merge.

* Add facilities to parse the errors from the jobs so we can replace it
  by more contextual and helpful errors.

* A logger which keeps in a buffer all the logs and flushes them when an error
  occurs in a synchronization, clears them if it succeeded
