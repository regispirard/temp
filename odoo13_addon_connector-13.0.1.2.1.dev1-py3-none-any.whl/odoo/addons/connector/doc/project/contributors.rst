.. _contributors:

############
Contributors
############

List of contributors:

.. include:: ../../AUTHORS


.. _financial-contributors:

######################
Financial Contributors
######################

A fund raising has been done during the year 2013, allowing us to develop
the connector framework and the Magento connector.

Here is the list of the funders, ordered by the amount of the contribution:

* **Logic Supply**
* **Debonix**
* Apertoso
* OpenBIG
* Smile
* IT Service Partners
* WillowIT
* Eezee-It
* Auguria
* Enova
* Mr. Goran Sunjka
* Taktik
* Maison del Gusto
* Open2bizz Software
* Bee Company
* initOS
* Rhônalia
* Julius Network Solutions
* Elico Corp
* Linko Solutions
* HSP Hanse Shopping
* Burn Out Italy
* Mr. Peter Dijkstra
* Mr. Luc Maurer
* Mr. Maxime Chambreuil
* Mr. Eric Vernichon
* Avanzosc
* Mr. Fabio Martinelli
* Mr. Marcelo Bello
* Rove.design
* Mr. Mark Felling

Thanks to all of them!
