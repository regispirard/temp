This module was written to extend the functionality of procurement groups
created from a sale order.

On itself, this module does nothing it is a requirement for modules which
needs to create procurement group per sale order line basis.
