from . import test_product_auto_bind
