This addon allows to assign an assortment to a ShopInvader
backend and get products auto-binded while exported
to search engine
