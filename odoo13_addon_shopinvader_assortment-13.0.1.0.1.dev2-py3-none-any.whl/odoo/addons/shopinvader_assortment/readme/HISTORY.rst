10.0.1.0.0 (2018-11-02)
~~~~~~~~~~~~~~~~~~~~~~~

* [ADD] add shopinvader_assortment addon

12.0.1.0.0 (2019-06-03)
~~~~~~~~~~~~~~~~~~~~~~~

* [12.0][MIG] shopinvader_assortment
