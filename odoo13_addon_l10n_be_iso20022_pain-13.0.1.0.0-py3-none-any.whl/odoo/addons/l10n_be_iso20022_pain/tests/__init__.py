from . import test_l10n_be_iso20022_pain
