cmis_report_write
=================
This module allows to save report into the cmis location of the related object
that is rendered into the report.

Configuration
=============

To make this module functional you have to use a patched odoo version found here:
https://github.com/acsone/odoo/tree/9.0-report_postprocess_hook-lmi

Credits
=======

Contributors
------------

* Laurent Mignon <laurent.mignon@acsone.eu>
