In some situations, one would have user restrictions on payment lines level.

This includes :

* An option to make payment amount readonly
* An option that adds a helper to disable the 'Validate' button (e.g.:
  waiting for an automatic payment transaction to be completed)
