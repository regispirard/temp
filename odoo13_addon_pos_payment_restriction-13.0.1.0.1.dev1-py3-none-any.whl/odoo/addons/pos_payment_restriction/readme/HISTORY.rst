9.0.1.0.0 (2019-11-06)
~~~~~~~~~~~~~~~~~~~~~~

* [9.0][ADD] pos_payment_restriction
