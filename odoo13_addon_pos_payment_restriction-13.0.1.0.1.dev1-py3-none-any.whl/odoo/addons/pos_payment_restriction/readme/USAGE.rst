* Go to Point of Sale
* Go to Configuration / Point of sale and click the PoS you want to configure
* In the Payments section check 'Prefill Cash Payment' and 'Payment amount readonly'

On POS payment screen, the tendered amount cannot be modified
