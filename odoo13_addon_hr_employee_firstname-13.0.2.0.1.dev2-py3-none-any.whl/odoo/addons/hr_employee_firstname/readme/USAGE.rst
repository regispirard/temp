On the employee form view you will have 2 separate fields, one for Firstname,
second for Lastname. At least one of them is required.
