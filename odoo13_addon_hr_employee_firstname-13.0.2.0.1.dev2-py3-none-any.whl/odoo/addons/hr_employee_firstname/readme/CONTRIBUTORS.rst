* El Hadji Dem <elhadji.dem@savoirfairelinux.com>
* Sandy Carter <sandy.carter@savoirfairelinux.com>
* Fekete Mihai <feketemihai@gmail.com>
* David Dufresne <david.dufresne@savoirfairelinux.com>
* Adrien Peiffer (ACSONE) <adrien.peiffer@acsone.eu>
* Antonio Esposito (ONESTEIN BV) <a.esposito@onestein.nl>
* Andrea Stirpe <a.stirpe@onestein.nl>
