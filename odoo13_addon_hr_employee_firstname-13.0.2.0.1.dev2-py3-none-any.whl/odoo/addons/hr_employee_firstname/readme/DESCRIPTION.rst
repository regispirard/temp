This module allows you to add firstname and lastname in employee form,
and concatenate both in name field.
