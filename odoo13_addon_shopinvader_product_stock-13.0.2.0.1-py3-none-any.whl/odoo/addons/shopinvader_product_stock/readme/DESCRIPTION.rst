This is shopinvader product stock module.
This module is used to export a specific stock field on product.product,
only if the value has been updated.
