* Sébastien BEAU <sebastien.beau@akretion.com>
* François Honoré <francois.honore@acsone.eu>
* Laurent Mignon <laurent.mignon@acsone.eu>
* Denis Roussel <denis.roussel@acsone.eu>
* Simone Orsi <simahawk@gmail.com>
