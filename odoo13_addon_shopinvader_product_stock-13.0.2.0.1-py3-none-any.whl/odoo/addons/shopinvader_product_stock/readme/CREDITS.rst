Funders
-------

The development of this module has been financially supported by:

* Akretion R&D
* Adaptoo
* Encresdubuit
* Abilis
