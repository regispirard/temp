Example:

If you want to have an analytic account on all your *expenses*,
set the policy to *always* for the account type *expense*
If you try to save an account move line with an account of type *expense*
without analytic account, you will get an error message.

The analytic policy is company dependent. If you have a multi-company
environment, you should set its value for all companies.
