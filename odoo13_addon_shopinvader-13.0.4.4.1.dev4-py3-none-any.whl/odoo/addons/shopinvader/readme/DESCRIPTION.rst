This is shopinvader the odoo module for the new generation of e-commerce.

ShopInvader is an ecommerce software to create and manage easily your online store with Odoo.

This is the Odoo side of the `Shopinvader E-commerce Solution`_.

.. _Shopinvader E-commerce Solution: https://shopinvader.com
