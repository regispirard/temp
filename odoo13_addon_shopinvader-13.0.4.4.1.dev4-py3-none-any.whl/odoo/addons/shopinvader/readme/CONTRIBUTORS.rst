* Sebastien BEAU <sebastien.beau@akretion.com>
* Simone Orsi <simone.orsi@camptocamp.com>
* Laurent Mignon <laurent.mignon@acsone.eu>
