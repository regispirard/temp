10.0.1.0.0 (2017-04-11)
~~~~~~~~~~~~~~~~~~~~~~~

* First real version : [REF] rename project to the real name : shoptor is dead long live to shopinvader", 2017-04-11)

12.0.1.0.0 (2019-05-10)
~~~~~~~~~~~~~~~~~~~~~~~

* [12.0][MIG] shopinvader
