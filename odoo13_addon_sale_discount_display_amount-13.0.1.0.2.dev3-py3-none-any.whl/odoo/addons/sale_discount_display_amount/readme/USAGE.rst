
To use this module, you need to:

#. Go on a sale order
#. Set a discount on a line
#. The value of the discount is dislayed in the total section as well as the total without it.
