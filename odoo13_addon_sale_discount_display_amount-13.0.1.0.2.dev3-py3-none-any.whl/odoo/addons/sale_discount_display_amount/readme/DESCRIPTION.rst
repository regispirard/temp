In standard Odoo only display the rate of the discount applied, never the
amount. It could be great to be able to tell the customer how much he spares.
This is the goal of this addons, it will show on a sale
order the total without the discount and the value of the discount.
