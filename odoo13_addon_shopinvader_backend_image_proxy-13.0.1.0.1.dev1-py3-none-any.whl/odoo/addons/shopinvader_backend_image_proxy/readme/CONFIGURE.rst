* By interface:

- Browse into your shopinvader backends
- Fill the field "image_proxy_url" if necessary
