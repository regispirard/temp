* Holger Brunn <hbrunn@therp.nl>
* Stefan Rijnhart <stefan@opener.am>
* Sylvain LE GAL (https://twitter.com/legalsylvain)
* Hieu, Vo Minh Bao <hieu.vmb@komit-consulting.com>
* Lorenzo Battistini <https://github.com/eLBati>
* Dennis Sluijk <d.sluijk@onestein.nl>
