To use this module, you need to:

#. Create a sale order and set a discount,
   this discount will be set in all lines.
#. Also you can set a discount in a partner.
