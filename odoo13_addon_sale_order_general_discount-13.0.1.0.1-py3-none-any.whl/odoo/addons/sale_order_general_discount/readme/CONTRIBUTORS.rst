* Raf Ven <raf.ven@dynapps.be>
* Sudhir Arya <sudhir@erpharbor.com>
* `Tecnativa <https://www.tecnativa.com>`_:

  * Sergio Teruel
  * Carlos Roca
