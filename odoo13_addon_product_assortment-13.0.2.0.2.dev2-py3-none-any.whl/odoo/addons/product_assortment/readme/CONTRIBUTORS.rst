* Denis Roussel <denis.roussel@acsone.eu>
* Cédric Pigeon <cedric.pigeon@acsone.eu>
* `Tecnativa <https://www.tecnativa.com>`_:

  * Carlos Roca
