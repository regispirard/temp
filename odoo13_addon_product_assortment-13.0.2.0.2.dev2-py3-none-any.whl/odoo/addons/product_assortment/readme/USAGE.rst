
To use this module, you need to:

#. Enter the menu through Product Assortment Icon
#. Create a new filter where you can define your domain and add whitelisted and blacklisted products
