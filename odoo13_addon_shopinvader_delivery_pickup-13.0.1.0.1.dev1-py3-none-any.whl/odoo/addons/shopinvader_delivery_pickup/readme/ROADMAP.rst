For now the module only implement an api rest for setting the dropoffsite.

TODO:
- add the possibility to search a dropoff_site with geo location
