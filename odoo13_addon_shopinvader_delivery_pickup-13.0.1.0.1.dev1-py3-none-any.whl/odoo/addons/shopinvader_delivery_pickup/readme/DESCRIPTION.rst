This is shopinvader the odoo module for the new generation of e-commerce.

This module is a base module for supporting dropoffsite


.. _Shopinvader: https://shopinvader.com
