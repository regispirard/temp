This ShopInvader submodule give the possibility to specify some
sale profiles (with pricelist per profile) per backend to apply on
your customers
