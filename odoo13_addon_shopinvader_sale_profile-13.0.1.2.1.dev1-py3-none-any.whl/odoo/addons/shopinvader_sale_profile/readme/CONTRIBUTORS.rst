* François Honoré <francois.honore@acsone.eu>
* Cédric PIGEON <cedric.pigeon@acsone.eu>
* Sebastien BEAU <sebastien.beau@akretion.com>
* Benoît GUILLOT <benoit.guillot@akretion.com>
* Simone Orsi <simahawk@gmail.com>
