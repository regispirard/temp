This module, add a new computed field to sale order to make shipping info accessible for report or e-commerce.
