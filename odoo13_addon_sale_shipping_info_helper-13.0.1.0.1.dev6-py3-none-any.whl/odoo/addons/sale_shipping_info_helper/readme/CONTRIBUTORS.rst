* Sébastien BEAU <sebastien.beau@akretion.com>
* Mourad EL HADJ MIMOUNE <mourad.elhadj.mimoune@akretion.com>
* Denis Roussel <denis.roussel@acsone.eu>
* Simone Orsi <simone.orsi@camptocamp.com>
