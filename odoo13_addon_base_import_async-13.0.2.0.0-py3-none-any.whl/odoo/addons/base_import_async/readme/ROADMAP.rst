* There is currently no user interface to control the chunk size,
  which is currently 100 by default. Should this proves to be an issue,
  it is easy to add an option to extend the import screen.
* Validation cannot be run in the background.
