This module adds the possibility to connect with the same account
on more than one device at the same time.

All providers are supported (Google, Facebook, Odoo, etc).
