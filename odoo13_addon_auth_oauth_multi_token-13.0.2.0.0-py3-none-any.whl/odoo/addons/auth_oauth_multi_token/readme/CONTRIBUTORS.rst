* Florent de Labarre <florent.mirieu@gmail.com>
* Simone Orsi <simone.orsi@camptocamp.com>
* `Tecnativa <https://www.tecnativa.com/>`__:

  * Jairo Llopis

  * Stéphane Bidoul <stephane.bidoul@acsone.eu>
