* Sebastien BEAU <sebastien.beau@akretion.com>
* Benoit GUILLOT <benoit.guillot@akretion.com>
* Laurent MIGNON <laurent.mignon@acsone.eu>
* Cédric PIGEON <cedric.pigeon@acsone.eu>
* Denis ROUSSEL <denis.roussel@acsone.eu>
* Simone Orsi <simone.orsi@camptocamp.com>
