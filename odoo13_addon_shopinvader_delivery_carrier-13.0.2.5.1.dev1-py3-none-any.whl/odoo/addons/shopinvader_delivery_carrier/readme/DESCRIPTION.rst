Add the configuration and the logic to manage the carrier on your ShopInvader site
