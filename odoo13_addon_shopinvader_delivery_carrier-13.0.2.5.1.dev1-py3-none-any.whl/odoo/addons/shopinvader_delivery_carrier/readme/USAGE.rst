This module will give you several endpoint for interacting with delivery carrier.
You can play with it with swagger.

Becarefull the key "rows" and "count" in the endpoint "delivery_carrier" are deprecated.
