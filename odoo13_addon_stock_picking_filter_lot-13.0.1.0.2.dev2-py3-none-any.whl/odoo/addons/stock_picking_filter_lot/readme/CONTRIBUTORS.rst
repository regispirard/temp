* Simone Rubino <simone.rubino@agilebg.com> (www.agilebg.com)
* Lois Rilo <lois.rilo@forgeflow.com> (www.forgeflow.com)
* Alan Ramos <alan.ramos@jarsa.com.mx> (www.jarsa.com.mx)
* Tharathip Chaweewongphan <tharathipc@ecosoft.co.th> (www.ecosoft.co.th)
