REST Services for ATOS Worldline SIPS Payments (/shopinvader route).
