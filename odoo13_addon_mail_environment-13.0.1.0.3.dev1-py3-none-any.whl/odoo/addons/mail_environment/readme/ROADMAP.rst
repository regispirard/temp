* Due to the special nature of this addon, you cannot test it on the OCA
  runbot.
