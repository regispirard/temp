Once configured, Odoo will read the mail servers values from the
configuration file related to each environment defined in the main
Odoo file.
