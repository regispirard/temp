To install this module, you need to have the server_environment module
installed and properly configured.
