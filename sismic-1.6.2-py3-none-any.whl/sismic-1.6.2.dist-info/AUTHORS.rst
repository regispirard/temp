Credits
=======

Development Lead
----------------

* Alexandre Decan

Contributors
------------

* Tom Mens
* Mathieu Goeminne
* Ali Parsai
* Nikos Spanoudakis
* Timothy Rule
* Jan Wouter Versluis
* Frederik Mathiesen
* Stéphane Bidoul
