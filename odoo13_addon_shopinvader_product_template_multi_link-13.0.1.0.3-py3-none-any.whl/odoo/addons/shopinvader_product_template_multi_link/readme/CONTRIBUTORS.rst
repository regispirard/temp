* Sébastien BEAU <sebastien.beau@akretion.com>
* Sylvain LE GAL (https://www.twitter.com/legalsylvain)
* Laurent Mignon <laurent.mignon@acsone.eu>
* Simone Orsi <simahawk@gmail.com>
