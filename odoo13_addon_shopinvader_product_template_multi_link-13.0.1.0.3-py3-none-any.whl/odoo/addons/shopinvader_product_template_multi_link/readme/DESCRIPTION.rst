Integrate `product_template_multi_link` into Shopinvader.
This module takes care of computing product links data
for search engine product indexes.
Index data is computed as a mapping of variants by link type.
