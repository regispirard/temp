* This module allows to restrict lot auto creation during picking flow
  for product with tracking per serial only.
