Base module for connecting Odoo with external search engines.
