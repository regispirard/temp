Changelog
---------

Future (?)
~~~~~~~~~~

12.0.2.0.0
~~~~~~~~~~

- index field name is now a computed field based on the backend name, the model exported and the lang
- remove dependency on keychain
- Improve UI on search engine backend (domain on model and exporter...)
- improve test coverage
- use black for auto code style
