.. image:: https://img.shields.io/badge/licence-AGPL--3-blue.svg
   :target: http://www.gnu.org/licenses/agpl-3.0-standalone.html
   :alt: License: AGPL-3

=================================
CMIS Connector Alfresco Extension
=================================

This module extend the CMIS connector with specifics functionalities provided by alfresco:

* Open CMIS content into Alfresco Share


Documentation: `alfodoo.org <http://alfodoo.org>`_ 


Credits
=======

Contributors
------------

* Laurent Mignon <laurent.mignon@acsone.eu>

Maintainer
----------

.. image:: https://www.acsone.eu/logo.png
   :alt: ACSONE SA/NV
   :target: http://www.acsone.eu

This module is maintained by ACSONE SA/NV.
