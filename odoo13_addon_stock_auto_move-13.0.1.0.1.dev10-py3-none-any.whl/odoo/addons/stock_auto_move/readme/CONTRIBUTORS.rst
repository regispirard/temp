* Nicolas Piganeau <nicolas.piganeau@ndp-systemes.fr>
* Cédric Pigeon <cedric.pigeon@acsone.eu>
* Denis Roussel <denis.roussel@acsone.eu>
