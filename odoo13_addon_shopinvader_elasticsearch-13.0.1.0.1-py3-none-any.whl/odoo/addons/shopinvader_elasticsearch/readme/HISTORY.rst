10.0.1.0.0 (2019-03-28)
~~~~~~~~~~~~~~~~~~~~~~~

* [ADD] shopinvader-elasticsearch: Shopinvader Elasticsearch Connector

12.0.1.0.0 (2019-05-22)
~~~~~~~~~~~~~~~~~~~~~~~

* [12.0][MIG] shopinvader_elasticsearch

13.0.1.0.0 (2019-12-19)
~~~~~~~~~~~~~~~~~~~~~~~

* [13.0][MIG] shopinvader_elasticsearch
