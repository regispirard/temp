Add Elasticsearch to search engines.
