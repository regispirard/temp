from . import test_shopinvader_elasticsearch
