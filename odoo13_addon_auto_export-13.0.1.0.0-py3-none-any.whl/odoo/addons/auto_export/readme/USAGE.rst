To use this module, you need to:

#. Go to the new Auto Export menu
#. Create a new export template with a previously saved export
#. Specify some optional parameters such as a technical domain or another user than Admin
#. Select a saving protocol (and a path if Filesystem is selected)
#. Save and click on the Trigger Export button to create the asynchronous export job
