Auto-installable module for the compatibility between

- shopinvader_locomotive
- shopinvader_sale_profile

This module will override the "role" field on the customer record based on matching profile.
