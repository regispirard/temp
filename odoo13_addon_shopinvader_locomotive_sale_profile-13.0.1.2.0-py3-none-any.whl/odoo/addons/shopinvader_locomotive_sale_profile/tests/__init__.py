from . import test_shopinvader_partner
