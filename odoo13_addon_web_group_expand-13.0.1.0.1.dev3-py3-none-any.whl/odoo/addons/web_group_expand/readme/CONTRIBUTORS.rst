* Mantavya Gajjar <mga@openerp.com>
* Oihane Crucelaegui <oihanecrucelaegi@avanzosc.es>
* Pedro M. Baeza <pedro.baeza@serviciosbaeza.com>
* Jay Vora (SerpentCS) for their alternative implementation
* Jan Verbeek <jverbeek@therp.nl>
* Manuel Calero <manuelcalerosolis@gmail.com>
